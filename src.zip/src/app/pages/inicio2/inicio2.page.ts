import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inicio2',
  templateUrl: './inicio2.page.html',
  styleUrls: ['./inicio2.page.scss'],
})
export class Inicio2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
